var surname = prompt ('введите фамилию :') 
var name = prompt ('введите имя :')
console.log ('Привет', surname + ' ' + name );